-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2026 at 09:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bce_resit`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendees`
--

CREATE TABLE `attendees` (
  `attendee_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendees`
--

INSERT INTO `attendees` (`attendee_id`, `booking_id`, `full_name`, `email`) VALUES
(1, 1, 'will', 'willsmith@gmail.com'),
(2, 2, 'will', 'willsmith@gmail.com'),
(3, 3, 'will', 'willsmith@gmail.com'),
(4, 4, 'john', 'john@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `booking_reference` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `booking_status` enum('confirmed','cancelled') NOT NULL DEFAULT 'confirmed',
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `booking_reference`, `user_id`, `event_id`, `quantity`, `unit_price`, `discount_amount`, `total_amount`, `booking_status`, `booking_date`) VALUES
(1, 'BCE-45CFA75B', 1, 1, 1, 15.00, 0.00, 15.00, 'confirmed', '2026-07-16 13:33:47'),
(2, 'BCE-48984831', 1, 1, 1, 15.00, 0.00, 15.00, 'confirmed', '2026-07-16 14:36:31'),
(3, 'BCE-D8962761', 1, 2, 1, 3.00, 0.00, 3.00, 'confirmed', '2026-07-16 20:50:33'),
(4, 'BCE-7B19E849', 1, 1, 1, 15.00, 0.00, 15.00, 'confirmed', '2026-07-17 19:00:04');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(6, 'Community'),
(4, 'Exhibition'),
(1, 'Music'),
(5, 'Religious'),
(2, 'Sport'),
(3, 'Workshop');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `event_date` date NOT NULL,
  `start_time` time NOT NULL,
  `venue` varchar(150) NOT NULL,
  `capacity` int(11) NOT NULL,
  `ticket_price` decimal(10,2) NOT NULL,
  `status` enum('active','cancelled') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `category_id`, `title`, `description`, `event_date`, `start_time`, `venue`, `capacity`, `ticket_price`, `status`) VALUES
(1, 1, 'Bristol Summer Music Night', 'An evening of live music featuring local Bristol performers.', '2026-07-25', '18:30:00', 'Bristol Harbourside', 200, 15.00, 'active'),
(2, 2, '5 aside football', '5 aside football bring your mates for a kick about', '2026-07-23', '18:00:00', 'goals filtonn bristol', 15, 3.00, 'active'),
(3, 1, 'Bristol Harbourside Live Music Evening', 'An outdoor evening of live music featuring local Bristol bands, acoustic performers and food stalls. The event is suitable for families and visitors who want to experience Bristol’s local music scene.', '2026-08-15', '18:30:00', 'Bristol Harbourside', 250, 18.00, 'active'),
(4, 2, 'Bristol Community 5K Run', 'A friendly five-kilometre running event for beginners, experienced runners and families. Participants will follow a marked route around Ashton Court and receive a completion certificate.', '2026-08-22', '09:00:00', 'Ashton Court Estate', 300, 10.00, 'active'),
(5, 3, 'introduction to Street Photography', 'A practical photography workshop teaching composition, lighting and storytelling techniques. Participants will explore central Bristol and practise taking photographs with a camera or smartphone.', '2026-09-05', '11:00:00', 'Watershed, Bristol', 35, 25.00, 'active'),
(6, 4, 'Bristol Local Artists Exhibition', 'An exhibition celebrating paintings, photography and sculpture created by artists from Bristol and the surrounding area. Visitors can meet selected artists and learn about their creative work.', '2026-09-12', '10:00:00', 'M Shed, Bristol', 180, 8.50, 'active'),
(7, 6, 'Bristol Community Culture Day', 'A celebration of Bristol’s diverse communities featuring traditional food, music, dance performances, craft activities and information stalls from local organisations.', '2026-09-19', '12:00:00', 'College Green, Bristol', 400, 5.00, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` enum('paid','failed','refunded') NOT NULL,
  `transaction_reference` varchar(50) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `booking_id`, `amount`, `payment_method`, `payment_status`, `transaction_reference`, `payment_date`) VALUES
(1, 1, 15.00, 'Test card', 'paid', 'PAY-73885FFAA8', '2026-07-16 13:33:47'),
(2, 2, 15.00, 'Test card', 'paid', 'PAY-2381185AEC', '2026-07-16 14:36:31'),
(3, 3, 3.00, 'Test card', 'paid', 'PAY-622CB933DC', '2026-07-16 20:50:33'),
(4, 4, 15.00, 'Test card', 'paid', 'PAY-8932663A26', '2026-07-17 19:00:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password_hash`, `role`, `created_at`) VALUES
(1, 'willsmith', 'willsmith@gmail.com', 'scrypt:32768:8:1$WbxDpUZ0SR8HRp4K$462198a8d7efa5dab015163ff675a036661ad3428b841da280c5ef862c59e51487ebe266c2dd077cd58bf4102b983cf14f72e88c5d8b2bb658999f575b51e20c', 'user', '2026-07-16 13:22:34'),
(2, 'suleban', 'suleban@gmail.com', 'scrypt:32768:8:1$1AEfW0o59DH86mTt$c4ce58eda151403eb95445cad87e95faeaca27bec8808f13211bc7a15413b444006f179694b985080f750af5ad7861fe02232a00106e19567d7cfd9a9355685e', 'admin', '2026-07-16 13:52:16'),
(3, 'john smith', 'johnsmith@gmail.com', 'scrypt:32768:8:1$oKJEGTSA7dJCPk8t$4b74690175684cf252c225f513a304f5d20f61265b3c04ed283e15fc22859c69a691054bc0c48c94b33264eb73b0263ee97a70036c666a73943097fc1569673a', 'user', '2026-07-17 19:06:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendees`
--
ALTER TABLE `attendees`
  ADD PRIMARY KEY (`attendee_id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD UNIQUE KEY `booking_reference` (`booking_reference`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD UNIQUE KEY `booking_id` (`booking_id`),
  ADD UNIQUE KEY `transaction_reference` (`transaction_reference`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendees`
--
ALTER TABLE `attendees`
  MODIFY `attendee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendees`
--
ALTER TABLE `attendees`
  ADD CONSTRAINT `attendees_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`);

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`);

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
